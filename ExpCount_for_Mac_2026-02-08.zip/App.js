import "react-native-gesture-handler";
import { StatusBar } from "expo-status-bar";
import { NavigationContainer, DarkTheme } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { createNativeBottomTabNavigator } from "@react-navigation/bottom-tabs/unstable";
import { createDrawerNavigator } from "@react-navigation/drawer";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { Ionicons } from "@expo/vector-icons";
import { useContext, useMemo } from "react";
import { Platform } from "react-native";

import LoginScreen from "./screens/LoginLogoutScreens/LogInScreen";
import SignupScreen from "./screens/LoginLogoutScreens/SignUpScreen";
import ExpensesScreen from "./screens/HomeScreenStack/ExpensesScreen";
import ManageExpenses from "./screens/HomeScreenStack/ManageExpenses";
import QuickAddExpenseScreen from "./screens/HomeScreenStack/QuickAddExpenseScreen";
import InsightsScreen from "./screens/HomeScreenStack/InsightsScreen";

import BudgetScreen from "./screens/DrawerScreens/BudgetScreen";
import BudgetOverviewScreen from "./screens/DrawerScreens/BudgetOverviewScreen";
import BudgetsHubScreen from "./screens/DrawerScreens/BudgetsHubScreen";

import RecurringScreen from "./screens/DrawerScreens/RecurringScreen";
import CustomizeScreen from "./screens/DrawerScreens/CustomizeScreen";
import PaymentsScreen from "./screens/DrawerScreens/PaymentsScreen";
import SettingsScreen from "./screens/DrawerScreens/SettingsScreen";
import CategoriesManagerScreen from "./screens/DrawerScreens/CategoriesManagerScreen";

import AuthContextProvider, { AuthContext } from "./store/auth-context";
import ExpensesContextProvider from "./store/expenses-context";
import ThemeContextProvider, { ThemeContext } from "./store/theme-context";
import BudgetContextProvider from "./store/budget-context";
import CustomizationContextProvider, {
  CustomizationContext,
} from "./store/customization-context";
import PaymentContextProvider from "./store/payment-context";
import ExpenseCategoriesContextProvider from "./store/expense-categories-context";

import IconButton from "./components/ui/IconButton";

const Stack = createStackNavigator();
const BottomTabs = createBottomTabNavigator();
const NativeBottomTabs = createNativeBottomTabNavigator();
const Drawer = createDrawerNavigator();

function useNavTheme(colors, themeVersion) {
  return useMemo(() => {
    return {
      ...DarkTheme,
      colors: {
        ...DarkTheme.colors,
        background: colors.primary800,
        card: colors.primary800,
        text: colors.textTitle,
        border: colors.white10,
        primary: colors.accent500,
      },
    };
  }, [
    themeVersion,
    colors.primary800,
    colors.textTitle,
    colors.white10,
    colors.accent500,
  ]);
}

function screenHeader(colors, textScale = 1) {
  return {
    headerStyle: {
      backgroundColor: colors.primary800,
      height: 100,
    },
    headerTintColor: colors.textTitle,
    headerTitleStyle: {
      fontWeight: "900",
      fontSize: Math.round(16 * textScale),
    },
    headerLeftContainerStyle: { paddingLeft: 6 },
    headerRightContainerStyle: { paddingRight: 6 },
    headerShadowVisible: false,
    headerBackTitleVisible: false,
  };
}

function screenContent(colors) {
  return { contentStyle: { backgroundColor: colors.primary800 } };
}

function getIOSGlassTabStyle(colors) {
  const isDark = colors.textTitle === "#ffffff";
  return {
    backgroundColor: isDark ? "rgba(20,20,26,0.70)" : "rgba(250,250,255,0.72)",
    shadowColor: "transparent",
  };
}

function AuthStack() {
  const { colors } = useContext(ThemeContext);
  const { textScale } = useContext(CustomizationContext);

  return (
    <Stack.Navigator
      screenOptions={{
        ...screenHeader(colors, textScale),
        ...screenContent(colors),
      }}
    >
      <Stack.Screen
        name="Accedi"
        component={LoginScreen}
        options={{ title: "Accedi" }}
      />
      <Stack.Screen
        name="Registrazione"
        component={SignupScreen}
        options={{ title: "Crea account" }}
      />
    </Stack.Navigator>
  );
}

function ExpensesTabs() {
  if (Platform.OS === "ios") return <ExpensesTabsNativeIOS />;
  return <ExpensesTabsClassic />;
}

function ExpensesTabsNativeIOS() {
  const { colors } = useContext(ThemeContext);
  const { textScale } = useContext(CustomizationContext);

  return (
    <NativeBottomTabs.Navigator
      screenOptions={{
        headerShown: true,
        ...screenHeader(colors, textScale),
        tabBarStyle: getIOSGlassTabStyle(colors),
        tabBarBlurEffect:
          colors.textTitle === "#ffffff"
            ? "systemUltraThinMaterialDark"
            : "systemUltraThinMaterialLight",
        tabBarActiveTintColor: colors.accent500,
        tabBarLabelStyle: {
          fontWeight: "900",
          fontSize: Math.round(12 * textScale),
        },
        tabBarMinimizeBehavior: "onScrollDown",
      }}
    >
      <NativeBottomTabs.Screen
        name="Expenses"
        component={ExpensesScreen}
        options={({ navigation }) => ({
          title: "Spese",
          tabBarLabel: "Spese",
          tabBarSystemItem: "bookmarks",
          headerLeft: () => (
            <IconButton
              icon="menu"
              size={24}
              color={colors.textTitle}
              onPress={() => navigation.getParent()?.openDrawer()}
            />
          ),
          headerRight: ({ tintColor }) => (
            <IconButton
              icon="add"
              size={24}
              color={tintColor || colors.textTitle}
              onPress={() => navigation.navigate("ManageExpenses")}
            />
          ),
        })}
      />

      <NativeBottomTabs.Screen
        name="Insights"
        component={InsightsScreen}
        options={({ navigation }) => ({
          title: "Insights",
          tabBarLabel: "Insights",
          tabBarSystemItem: "topRated",
          headerLeft: () => (
            <IconButton
              icon="menu"
              size={24}
              color={colors.textTitle}
              onPress={() => navigation.getParent()?.openDrawer()}
            />
          ),
        })}
      />
    </NativeBottomTabs.Navigator>
  );
}

function ExpensesTabsClassic() {
  const { colors } = useContext(ThemeContext);
  const { textScale } = useContext(CustomizationContext);

  return (
    <BottomTabs.Navigator
      screenOptions={{
        ...screenHeader(colors, textScale),
        tabBarStyle: {
          backgroundColor: colors.primary800,
          borderTopColor: colors.white10,
          borderTopWidth: 1,
          height: 76,
          paddingBottom: 10,
          paddingTop: 10,
        },
        tabBarActiveTintColor: colors.accent500,
        tabBarInactiveTintColor: colors.white55,
        tabBarLabelStyle: { fontWeight: "900", fontSize: Math.round(12 * textScale) },
        tabBarHideOnKeyboard: true,
      }}
    >
      <BottomTabs.Screen
        name="Expenses"
        component={ExpensesScreen}
        options={({ navigation }) => ({
          title: "Spese",
          tabBarLabel: "Spese",
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="wallet-outline" size={size} color={color} />
          ),
          headerLeft: () => (
            <IconButton
              icon="menu"
              size={24}
              color={colors.textTitle}
              onPress={() => navigation.getParent()?.openDrawer()}
            />
          ),
          headerRight: ({ tintColor }) => (
            <IconButton
              icon="add"
              size={24}
              color={tintColor || colors.textTitle}
              onPress={() => navigation.navigate("ManageExpenses")}
            />
          ),
        })}
      />

      <BottomTabs.Screen
        name="Insights"
        component={InsightsScreen}
        options={({ navigation }) => ({
          title: "Analisi",
          tabBarLabel: "Analisi",
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="bar-chart-outline" size={size} color={color} />
          ),
          headerLeft: () => (
            <IconButton
              icon="menu"
              size={24}
              color={colors.textTitle}
              onPress={() => navigation.getParent()?.openDrawer()}
            />
          ),
        })}
      />
    </BottomTabs.Navigator>
  );
}

function BudgetStack() {
  const { colors } = useContext(ThemeContext);
  const { textScale } = useContext(CustomizationContext);

  return (
    <Stack.Navigator
      screenOptions={{
        ...screenHeader(colors, textScale),
        ...screenContent(colors),
      }}
    >
      <Stack.Screen
        name="BudgetsHub"
        component={BudgetsHubScreen}
        options={({ navigation }) => ({
          title: "Budget",
          headerLeft: () => (
            <IconButton
              icon="menu"
              size={24}
              color={colors.textTitle}
              onPress={() => navigation.getParent()?.openDrawer()}
            />
          ),
        })}
      />

      <Stack.Screen
        name="BudgetOverview"
        component={BudgetOverviewScreen}
        options={({ navigation, route }) => ({
          title: route?.params?.title ? `Budget - ${route.params.title}` : "Budget",
          headerRight: () => (
            <IconButton
              icon="pencil"
              size={22}
              color={colors.textTitle}
              onPress={() =>
                navigation.navigate("BudgetScreen", {
                  budgetId: route?.params?.budgetId,
                })
              }
            />
          ),
        })}
      />

      <Stack.Screen
        name="BudgetScreen"
        component={BudgetScreen}
        options={{ title: "Modifica Budget" }}
      />
    </Stack.Navigator>
  );
}

function RecurringStack() {
  const { colors } = useContext(ThemeContext);
  const { textScale } = useContext(CustomizationContext);

  return (
    <Stack.Navigator
      screenOptions={{
        ...screenHeader(colors, textScale),
        ...screenContent(colors),
      }}
    >
      <Stack.Screen
        name="RecurringHome"
        component={RecurringScreen}
        options={({ navigation }) => ({
          title: "Abbonamenti/Abitudinali",
          headerLeft: () => (
            <IconButton
              icon="menu"
              size={24}
              color={colors.textTitle}
              onPress={() => navigation.getParent()?.openDrawer()}
            />
          ),
        })}
      />
    </Stack.Navigator>
  );
}

function PaymentsStack() {
  const { colors } = useContext(ThemeContext);
  const { textScale } = useContext(CustomizationContext);

  return (
    <Stack.Navigator
      screenOptions={{
        ...screenHeader(colors, textScale),
        ...screenContent(colors),
      }}
    >
      <Stack.Screen
        name="PaymentsHome"
        component={PaymentsScreen}
        options={({ navigation }) => ({
          title: "Carte e Contanti",
          headerLeft: () => (
            <IconButton
              icon="menu"
              size={24}
              color={colors.textTitle}
              onPress={() => navigation.getParent()?.openDrawer()}
            />
          ),
        })}
      />
    </Stack.Navigator>
  );
}

function SettingsStack() {
  const { colors } = useContext(ThemeContext);
  const { textScale } = useContext(CustomizationContext);

  return (
    <Stack.Navigator
      screenOptions={{
        ...screenHeader(colors, textScale),
        ...screenContent(colors),
      }}
    >
      <Stack.Screen
        name="SettingsHome"
        component={SettingsScreen}
        options={({ navigation }) => ({
          title: "Impostazioni",
          headerLeft: () => (
            <IconButton
              icon="menu"
              size={24}
              color={colors.textTitle}
              onPress={() => navigation.getParent()?.openDrawer()}
            />
          ),
        })}
      />
      <Stack.Screen
        name="CustomizeHome"
        component={CustomizeScreen}
        options={{ title: "Personalizzazione" }}
      />
      <Stack.Screen
        name="CategoriesManager"
        component={CategoriesManagerScreen}
        options={{ title: "Gestione Categorie" }}
      />
    </Stack.Navigator>
  );
}

function AppDrawer() {
  const authCtx = useContext(AuthContext);
  const { colors } = useContext(ThemeContext);
  const { textScale } = useContext(CustomizationContext);

  return (
    <Drawer.Navigator
      screenOptions={{
        headerShown: false,
        drawerStyle: { backgroundColor: colors.primary800, width: 290 },
        drawerActiveTintColor: colors.textTitle,
        drawerInactiveTintColor: colors.white70,
        drawerActiveBackgroundColor: colors.accent18,
        drawerLabelStyle: {
          fontWeight: "900",
          marginLeft: -10,
          fontSize: Math.round(14 * textScale),
        },
        drawerItemStyle: {
          borderRadius: 14,
          marginHorizontal: 10,
          marginVertical: 4,
        },
        sceneContainerStyle: { backgroundColor: colors.primary800 },
      }}
    >
      <Drawer.Screen
        name="Spese"
        component={ExpensesTabs}
        options={{
          title: "Spese",
          drawerIcon: ({ color, size }) => (
            <Ionicons name="wallet-outline" size={size} color={color} />
          ),
        }}
      />

      <Drawer.Screen
        name="Budget"
        component={BudgetStack}
        options={{
          title: "Budget",
          drawerIcon: ({ color, size }) => (
            <Ionicons name="cash-outline" size={size} color={color} />
          ),
        }}
      />

      <Drawer.Screen
        name="Recurring"
        component={RecurringStack}
        options={{
          title: "Abbonamenti/Abitudinali",
          drawerIcon: ({ color, size }) => (
            <Ionicons name="repeat-outline" size={size} color={color} />
          ),
        }}
      />

      <Drawer.Screen
        name="Payments"
        component={PaymentsStack}
        options={{
          title: "Carte/Contanti",
          drawerIcon: ({ color, size }) => (
            <Ionicons name="card-outline" size={size} color={color} />
          ),
        }}
      />

      <Drawer.Screen
        name="Settings"
        component={SettingsStack}
        options={{
          title: "Impostazioni",
          drawerIcon: ({ color, size }) => (
            <Ionicons name="settings-outline" size={size} color={color} />
          ),
        }}
      />

      <Drawer.Screen
        name="Logout"
        component={ExpensesTabs}
        options={{
          title: "Logout",
          drawerIcon: ({ color, size }) => (
            <Ionicons name="exit-outline" size={size} color={color} />
          ),
        }}
        listeners={{
          drawerItemPress: (e) => {
            e.preventDefault();
            authCtx.logout();
          },
        }}
      />
    </Drawer.Navigator>
  );
}

function AuthenticatedStack() {
  const { colors } = useContext(ThemeContext);
  const { textScale } = useContext(CustomizationContext);

  return (
    <Stack.Navigator
      screenOptions={{
        ...screenHeader(colors, textScale),
        ...screenContent(colors),
      }}
    >
      <Stack.Screen
        name="Drawer"
        component={AppDrawer}
        options={{ headerShown: false }}
      />

      <Stack.Screen
        name="QuickAddExpense"
        component={QuickAddExpenseScreen}
        options={{
          headerShown: false,
          presentation: "transparentModal",
          cardStyle: { backgroundColor: "transparent" },
        }}
      />

      <Stack.Screen
        name="ManageExpenses"
        component={ManageExpenses}
        options={{ title: "Gestisci Spesa", presentation: "modal" }}
      />
    </Stack.Navigator>
  );
}

function Navigation() {
  const authCtx = useContext(AuthContext);
  const { colors, version, ready } = useContext(ThemeContext);
  const { ready: prefsReady } = useContext(CustomizationContext);
  const navTheme = useNavTheme(colors, version);

  if (!ready || !prefsReady) return null;

  return (
    <>
      <StatusBar style={colors.textTitle === "#ffffff" ? "light" : "dark"} />
      <NavigationContainer theme={navTheme} key={version}>
        {!authCtx.isAuthenticated ? <AuthStack /> : <AuthenticatedStack />}
      </NavigationContainer>
    </>
  );
}

export default function App() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <AuthContextProvider>
        <ThemeContextProvider>
          <CustomizationContextProvider>
            <BudgetContextProvider>
              <PaymentContextProvider>
                <ExpenseCategoriesContextProvider>
                  <ExpensesContextProvider>
                    <Navigation />
                  </ExpensesContextProvider>
                </ExpenseCategoriesContextProvider>
              </PaymentContextProvider>
            </BudgetContextProvider>
          </CustomizationContextProvider>
        </ThemeContextProvider>
      </AuthContextProvider>
    </GestureHandlerRootView>
  );
}
