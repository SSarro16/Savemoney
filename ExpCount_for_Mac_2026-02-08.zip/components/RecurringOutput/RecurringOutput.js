import React from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { GlobalStyles } from "../../constants/styles";
import RecurringTimeline from "./RecurringTimeline";

function CreateCard({ title, subtitle, icon, onPress }) {
  const colors = GlobalStyles.colors;
  const styles = makeStyles(colors);

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [styles.createCard, pressed && { opacity: 0.92 }]}
    >
      <View style={styles.createIcon}>
        <Ionicons name={icon} size={18} color={colors.textTitle} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={styles.createTitle}>{title}</Text>
        <Text style={styles.createSub}>{subtitle}</Text>
      </View>
      <Ionicons name="chevron-forward" size={18} color={colors.textMuted} />
    </Pressable>
  );
}

export default function RecurringOutputHeader({
  items,
  onCreateHabit,
  onCreateSubscription,
  onAddAllDue,
  dueCount,
}) {
  const colors = GlobalStyles.colors;
  const styles = makeStyles(colors);

  return (
    <View style={{ gap: 12 }}>
      <View style={styles.topRow}>
        <CreateCard
          title="Nuova Abitudine"
          subtitle="Tocca per creare (aggiungi piu volte)"
          icon="flash-outline"
          onPress={onCreateHabit}
        />
        <CreateCard
          title="Nuovo Abbonamento"
          subtitle="Tocca per creare (paga a scadenza)"
          icon="repeat-outline"
          onPress={onCreateSubscription}
        />
      </View>

      {!!dueCount && (
        <Pressable
          onPress={onAddAllDue}
          style={({ pressed }) => [
            styles.addAllBtn,
            pressed && { opacity: 0.9 },
          ]}
        >
          <Ionicons
            name="checkmark-done"
            size={18}
            color={colors.textOnAccentStrong}
          />
          <Text style={styles.addAllText}>Aggiungi tutto ({dueCount})</Text>
        </Pressable>
      )}

      <RecurringTimeline items={items} />

      <View style={styles.sectionHead}>
        <View style={styles.sectionIcon}>
          <Ionicons name="list-outline" size={16} color={colors.textTitle} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.sectionTitle}>Le tue ricorrenze</Text>
          <Text style={styles.sectionSub}>
            Tocca per modificare - scorri per eliminare
          </Text>
        </View>
      </View>

      {!items?.length ? (
        <View style={styles.empty}>
          <Ionicons name="sparkles-outline" size={18} color={colors.textMuted} />
          <Text style={styles.emptyText}>
            Nessuna abitudine o abbonamento ancora.
          </Text>
        </View>
      ) : null}
    </View>
  );
}

function makeStyles(colors) {
  return StyleSheet.create({
    topRow: { flexDirection: "row", gap: 10 },

    createCard: {
      flex: 1,
      padding: 12,
      borderRadius: 18,
      backgroundColor: colors.white06,
      borderWidth: 1,
      borderColor: colors.white10,
      flexDirection: "row",
      alignItems: "center",
      gap: 10,
    },
    createIcon: {
      width: 40,
      height: 40,
      borderRadius: 14,
      backgroundColor: colors.accent18,
      borderWidth: 1,
      borderColor: colors.accent35,
      alignItems: "center",
      justifyContent: "center",
    },
    createTitle: { color: colors.textTitle, fontWeight: "900" },
    createSub: {
      marginTop: 2,
      color: colors.textMuted,
      fontWeight: "700",
      fontSize: 12,
    },

    addAllBtn: {
      height: 50,
      borderRadius: 16,
      alignItems: "center",
      justifyContent: "center",
      flexDirection: "row",
      gap: 8,
      backgroundColor: colors.accent500,
      borderWidth: 1,
      borderColor: colors.accent30,
    },
    addAllText: { color: colors.textOnAccentStrong, fontWeight: "900" },

    sectionHead: {
      flexDirection: "row",
      alignItems: "center",
      gap: 10,
      marginTop: 6,
      marginBottom: 10,
    },
    sectionIcon: {
      width: 34,
      height: 34,
      borderRadius: 14,
      backgroundColor: colors.white08,
      borderWidth: 1,
      borderColor: colors.white10,
      alignItems: "center",
      justifyContent: "center",
    },
    sectionTitle: { color: colors.textTitle, fontWeight: "900" },
    sectionSub: {
      marginTop: 2,
      color: colors.textMuted,
      fontWeight: "700",
      fontSize: 12,
    },

    empty: {
      padding: 14,
      borderRadius: 18,
      backgroundColor: colors.white06,
      borderWidth: 1,
      borderColor: colors.white10,
      flexDirection: "row",
      alignItems: "center",
      gap: 10,
    },
    emptyText: { color: colors.textBody, fontWeight: "800", flex: 1 },
  });
}
