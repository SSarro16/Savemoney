import {
  useContext,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  useCallback,
} from "react";
import {
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  View,
  Pressable,
  Text,
} from "react-native";
import * as Haptics from "expo-haptics";
import { Ionicons } from "@expo/vector-icons";
import { useHeaderHeight } from "@react-navigation/elements";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import IconButton from "../../components/ui/IconButton";
import { GlobalStyles } from "../../constants/styles";
import { ExpensesContext } from "../../store/expenses-context";
import { PaymentContext } from "../../store/payment-context";
import ExpenseForm from "../../components/ManageExpense/ExpenseForm";
import LoadingOverlay from "../../components/ui/LoadingOverlay";
import ErrorOverlay from "../../components/ui/ErrorOverlay";

import { addExpenseTemplate } from "../../util/expenses/expense-template";

// ✅ per normalizzare il metodo pagamento
import { PAYMENT_METHOD } from "../../util/expenses/expense-presets";

function safePayMethod(v) {
  return v === PAYMENT_METHOD.CARD ? PAYMENT_METHOD.CARD : PAYMENT_METHOD.CASH;
}

function ManageExpenses({ route, navigation }) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState(null);

  const colors = GlobalStyles.colors;
  const styles = makeStyles(colors);

  const expensesCtx = useContext(ExpensesContext);
  const paymentCtx = useContext(PaymentContext);

  const editedExpenseId = route.params?.expenseId;
  const isEditing = !!editedExpenseId;

  const preset = route.params?.preset;

  const selectedExpense = useMemo(() => {
    return expensesCtx.expenses.find(
      (expense) => expense.id === editedExpenseId,
    );
  }, [expensesCtx.expenses, editedExpenseId]);

  const lastActionRef = useRef(null);

  const headerHeight = useHeaderHeight();
  const insets = useSafeAreaInsets();
  const keyboardOffset = Platform.OS === "ios" ? headerHeight : 0;

  const formRef = useRef(null);

  const saveFavoriteHandler = useCallback(async () => {
    try {
      const draft = formRef.current?.getFavoriteDraft?.();
      if (!draft) return;

      if (!draft.description?.trim()) {
        Alert.alert(
          "Manca la descrizione",
          "Scrivi una descrizione per salvare nei preferiti.",
        );
        return;
      }

      // ✅ aggiungo anche metodo pagamento/cardId nel template
      const pm = safePayMethod(draft.payMethod);
      const cid =
        pm === PAYMENT_METHOD.CARD ? String(draft.cardId || "").trim() : "";

      await addExpenseTemplate({
        ...draft,
        payMethod: pm,
        ...(pm === PAYMENT_METHOD.CARD ? { cardId: cid } : {}),
      });

      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(
        () => {},
      );
      Alert.alert(
        "Salvato",
        "Aggiunto ai preferiti (lo trovi in Aggiunta Rapida)",
      );
    } catch {
      Alert.alert("Errore", "Impossibile salvare nei preferiti.");
    }
  }, []);

  function confirmDelete() {
    Alert.alert("Eliminare la spesa?", "Puoi annullare per alcuni secondi.", [
      { text: "Annulla", style: "cancel" },
      { text: "Elimina", style: "destructive", onPress: deleteExpenseHandler },
    ]);
  }

  useLayoutEffect(() => {
    navigation.setOptions({
      title: isEditing ? "Modifica Spesa" : "Aggiungi Spesa",
      headerRight: () => (
        <View style={styles.headerRight}>
          <Pressable
            onPress={saveFavoriteHandler}
            disabled={isSubmitting}
            style={({ pressed }) => [
              styles.saveBtn,
              pressed && !isSubmitting && { opacity: 0.88 },
              isSubmitting && { opacity: 0.6 },
            ]}
          >
            <Ionicons name="star-outline" size={18} color="white" />
            <Text style={styles.saveText}>Salva</Text>
          </Pressable>

          {isEditing ? (
            <IconButton
              icon="trash"
              color={colors.error500}
              size={22}
              onPress={confirmDelete}
            />
          ) : null}
        </View>
      ),
    });
  }, [navigation, isEditing, isSubmitting, saveFavoriteHandler]);

  async function deleteExpenseHandler() {
    if (!editedExpenseId || isSubmitting) return;

    lastActionRef.current = { type: "delete", id: editedExpenseId };
    setIsSubmitting(true);
    setError(null);

    try {
      await expensesCtx.deleteExpenseWithUndo(editedExpenseId);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning).catch(
        () => {},
      );
      navigation.goBack();
    } catch {
      setError("Impossibile eliminare la spesa! Riprova più tardi.");
      setIsSubmitting(false);
    }
  }

  function cancelHandler() {
    navigation.goBack();
  }

  async function confirmHandler(expenseData) {
    if (isSubmitting) return;

    lastActionRef.current = isEditing
      ? { type: "update", id: editedExpenseId, data: expenseData }
      : { type: "add", data: expenseData };

    setIsSubmitting(true);
    setError(null);

    try {
      if (isEditing) {
        await expensesCtx.updateExpense(editedExpenseId, expenseData);
      } else {
        await expensesCtx.addExpense(expenseData);
      }
      navigation.goBack();
    } catch {
      setError("Impossibile salvare la spesa! Riprova più tardi.");
      setIsSubmitting(false);
    }
  }

  async function retryLastAction() {
    const last = lastActionRef.current;
    if (!last || isSubmitting) return;

    setIsSubmitting(true);
    setError(null);

    try {
      if (last.type === "delete") {
        await expensesCtx.deleteExpenseWithUndo(last.id);
        navigation.goBack();
        return;
      }
      if (last.type === "update") {
        await expensesCtx.updateExpense(last.id, last.data);
        navigation.goBack();
        return;
      }
      if (last.type === "add") {
        await expensesCtx.addExpense(last.data);
        navigation.goBack();
        return;
      }
      setIsSubmitting(false);
    } catch {
      setError("Operazione non riuscita. Riprova più tardi.");
      setIsSubmitting(false);
    }
  }

  if (error && !isSubmitting) {
    return (
      <ErrorOverlay
        message={error}
        onRetry={retryLastAction}
        retryLabel="Riprova"
        retryDelayMs={2000}
      />
    );
  }

  if (isSubmitting) {
    return <LoadingOverlay message="Salvataggio in corso..." />;
  }

  const Wrapper = Platform.OS === "ios" ? KeyboardAvoidingView : View;

  return (
    <Wrapper
      style={styles.container}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
      keyboardVerticalOffset={keyboardOffset}
    >
      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingBottom: 24 + insets.bottom },
        ]}
        keyboardShouldPersistTaps="handled"
        keyboardDismissMode="interactive"
        showsVerticalScrollIndicator={false}
      >
        <ExpenseForm
          ref={formRef}
          submitButtonLabel={isEditing ? "Aggiorna" : "Aggiungi"}
          onCancel={cancelHandler}
          onSubmit={confirmHandler}
          defaultValues={selectedExpense ?? preset}
          autoFocusAmount={!isEditing}
          disabled={isSubmitting}
          cards={paymentCtx.cards}
          cashWallets={paymentCtx.cashWallets}
          defaultCashWalletId={paymentCtx.defaultCashWalletId}
        />
      </ScrollView>
    </Wrapper>
  );
}

export default ManageExpenses;

function makeStyles(colors) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.primary800 },
    content: { padding: 16 },

    headerRight: {
      flexDirection: "row",
      alignItems: "center",
      gap: 10,
      paddingRight: 6,
    },
    saveBtn: {
      flexDirection: "row",
      alignItems: "center",
      gap: 6,
      paddingVertical: 8,
      paddingHorizontal: 10,
      borderRadius: 14,
      backgroundColor: colors.white08,
      borderWidth: 1,
      borderColor: colors.white10,
    },
    saveText: { color: colors.textTitle, fontWeight: "900", fontSize: 12 },
  });
}

