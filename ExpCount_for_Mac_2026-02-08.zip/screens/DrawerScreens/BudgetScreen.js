import React, { useContext, useEffect } from "react";
import { View } from "react-native";
import { GlobalStyles } from "../../constants/styles";
import ManageBudget from "../../components/ManageBudget/ManageBudget";
import { BudgetContext } from "../../store/budget-context";

export default function BudgetScreen({ navigation, route }) {
  const colors = GlobalStyles.colors;
  const budgetCtx = useContext(BudgetContext);

  useEffect(() => {
    const budgetId = route?.params?.budgetId;
    if (!budgetId) return;
    budgetCtx.selectBudget?.(budgetId).catch(() => {});
  }, [route?.params?.budgetId, budgetCtx]);

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <ManageBudget onSave={() => navigation.goBack()} />
    </View>
  );
}
