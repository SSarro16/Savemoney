import React, { useContext, useMemo, useState } from "react";
import {
  Alert,
  Keyboard,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";

import { GlobalStyles } from "../../constants/styles";
import { PaymentContext } from "../../store/payment-context";
import { ExpensesContext } from "../../store/expenses-context";
import LoadingOverlay from "../../components/ui/LoadingOverlay";
import { formatDateIT } from "../../util/date";

function emptyCardDraft() {
  return { id: "", name: "", brand: "", last4: "", balance: "" };
}

function emptyCashDraft() {
  return { id: "", name: "", balance: "" };
}

function parseAmount(v) {
  const cleaned = String(v || "")
    .replace(",", ".")
    .replace(/[^\d.-]/g, "");
  const n = Number(cleaned);
  return Number.isFinite(n) ? n : 0;
}

function toUiErrorMessage(error, fallback) {
  const status = Number(error?.response?.status || 0);
  const rawError = error?.response?.data?.error;
  const raw =
    typeof rawError === "string"
      ? rawError.toLowerCase()
      : String(rawError?.message || "").toLowerCase();

  if (raw.includes("permission_denied") || raw.includes("permission denied")) {
    return "Accesso negato dal database. Verifica regole Firebase o endpoint.";
  }

  if (
    raw.includes("token expired") ||
    raw.includes("id token expired") ||
    raw.includes("invalid id token") ||
    raw.includes("invalid token")
  ) {
    return "Sessione scaduta. Effettua di nuovo l'accesso.";
  }

  if (status === 401 || status === 403) {
    return "Richiesta non autorizzata. Riprova tra qualche secondo.";
  }

  return error?.message || fallback;
}

function SectionHeader({ icon, title, subtitle, onAdd, colors, styles }) {
  return (
    <View style={styles.sectionHeader}>
      <View style={styles.sectionHeadLeft}>
        <View style={styles.sectionIconWrap}>
          <Ionicons name={icon} size={18} color={colors.textTitle} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.sectionTitle}>{title}</Text>
          <Text style={styles.sectionSub}>{subtitle}</Text>
        </View>
      </View>

      <Pressable
        onPress={onAdd}
        style={({ pressed }) => [styles.addBtn, pressed && { opacity: 0.9 }]}
      >
        <Ionicons name="add" size={18} color={colors.textOnAccentStrong} />
      </Pressable>
    </View>
  );
}

export default function PaymentsScreen() {
  const colors = GlobalStyles.colors;
  const styles = makeStyles(colors);
  const paymentCtx = useContext(PaymentContext);
  const expensesCtx = useContext(ExpensesContext);

  const [cardModalOpen, setCardModalOpen] = useState(false);
  const [cardDraft, setCardDraft] = useState(emptyCardDraft());

  const [cashModalOpen, setCashModalOpen] = useState(false);
  const [cashDraft, setCashDraft] = useState(emptyCashDraft());

  const [saving, setSaving] = useState(false);

  const recentPayments = useMemo(() => {
    return [...(expensesCtx.expenses || [])]
      .sort((a, b) => new Date(b?.date || 0).getTime() - new Date(a?.date || 0).getTime())
      .slice(0, 20);
  }, [expensesCtx.expenses]);

  const spentByCard = useMemo(() => {
    const map = new Map();
    for (const exp of expensesCtx.expenses || []) {
      const type = exp?.methodType === "CARD" || exp?.payMethod === "CARD" ? "CARD" : "CASH";
      if (type !== "CARD") continue;
      const cardId = String(exp?.methodId || exp?.cardId || "").trim();
      if (!cardId) continue;
      const amount = Number(exp?.amount || 0);
      if (!Number.isFinite(amount) || amount <= 0) continue;
      map.set(cardId, Number((Number(map.get(cardId) || 0) + amount).toFixed(2)));
    }
    return map;
  }, [expensesCtx.expenses]);

  const spentByCashWallet = useMemo(() => {
    const map = new Map();
    for (const exp of expensesCtx.expenses || []) {
      const type = exp?.methodType === "CARD" || exp?.payMethod === "CARD" ? "CARD" : "CASH";
      if (type !== "CASH") continue;
      const walletId = String(exp?.methodId || exp?.cashId || "").trim();
      if (!walletId) continue;
      const amount = Number(exp?.amount || 0);
      if (!Number.isFinite(amount) || amount <= 0) continue;
      map.set(walletId, Number((Number(map.get(walletId) || 0) + amount).toFixed(2)));
    }
    return map;
  }, [expensesCtx.expenses]);

  const openCreateCard = () => {
    setCardDraft(emptyCardDraft());
    setCardModalOpen(true);
  };

  const openEditCard = (card) => {
    setCardDraft({
      id: String(card?.id || ""),
      name: String(card?.name || ""),
      brand: String(card?.brand || ""),
      last4: String(card?.last4 || ""),
      balance: String(card?.balance ?? ""),
    });
    setCardModalOpen(true);
  };

  const saveCard = async () => {
    const name = String(cardDraft.name || "").trim();
    const last4 = String(cardDraft.last4 || "")
      .replace(/[^\d]/g, "")
      .slice(-4);
    const balance = parseAmount(cardDraft.balance);

    if (!name) {
      Alert.alert("Nome mancante", "Inserisci un nome carta.");
      return;
    }

    setSaving(true);
    try {
      if (cardDraft.id) {
        await paymentCtx.updateCard(cardDraft.id, {
          name,
          brand: String(cardDraft.brand || "").trim(),
          last4,
          balance,
        });
      } else {
        await paymentCtx.addCard({
          name,
          brand: String(cardDraft.brand || "").trim(),
          last4,
          balance,
        });
      }
      setCardModalOpen(false);
      Keyboard.dismiss();
    } catch (error) {
      Alert.alert("Errore", toUiErrorMessage(error, "Impossibile salvare la carta."));
    } finally {
      setSaving(false);
    }
  };

  const removeCard = (card) => {
    Alert.alert("Elimina carta", `Eliminare \"${card?.name || "Carta"}\"?`, [
      { text: "Annulla", style: "cancel" },
      {
        text: "Elimina",
        style: "destructive",
        onPress: async () => {
          try {
            await paymentCtx.deleteCard(card.id);
          } catch (error) {
            Alert.alert(
              "Errore",
              toUiErrorMessage(error, "Impossibile eliminare la carta."),
            );
          }
        },
      },
    ]);
  };

  const openCreateCash = () => {
    setCashDraft(emptyCashDraft());
    setCashModalOpen(true);
  };

  const openEditCash = (wallet) => {
    setCashDraft({
      id: String(wallet?.id || ""),
      name: String(wallet?.name || ""),
      balance: String(wallet?.balance ?? ""),
    });
    setCashModalOpen(true);
  };

  const saveCashWallet = async () => {
    const name = String(cashDraft.name || "").trim();
    if (!name) {
      Alert.alert("Nome mancante", "Inserisci il nome del wallet contanti.");
      return;
    }
    const balance = parseAmount(cashDraft.balance);

    setSaving(true);
    try {
      if (cashDraft.id) {
        await paymentCtx.updateCashWallet(cashDraft.id, { name, balance });
      } else {
        const shouldDefault = paymentCtx.cashWallets.length === 0;
        await paymentCtx.addCashWallet({ name, balance, isDefault: shouldDefault });
      }
      setCashModalOpen(false);
      Keyboard.dismiss();
    } catch (error) {
      Alert.alert("Errore", toUiErrorMessage(error, "Impossibile salvare il wallet."));
    } finally {
      setSaving(false);
    }
  };

  const removeCashWallet = (wallet) => {
    Alert.alert("Elimina wallet", `Eliminare \"${wallet?.name || "Contanti"}\"?`, [
      { text: "Annulla", style: "cancel" },
      {
        text: "Elimina",
        style: "destructive",
        onPress: async () => {
          try {
            await paymentCtx.deleteCashWallet(wallet.id);
          } catch (error) {
            Alert.alert(
              "Errore",
              toUiErrorMessage(error, "Impossibile eliminare il wallet."),
            );
          }
        },
      },
    ]);
  };

  if (
    !paymentCtx.initialized &&
    paymentCtx.loading &&
    !paymentCtx.cards.length &&
    !paymentCtx.cashWallets.length
  ) {
    return <LoadingOverlay message="Caricamento metodi di pagamento..." />;
  }

  return (
    <View style={styles.screen}>
      <View style={styles.hero}>
        <View style={styles.heroIcon}>
          <Ionicons name="wallet-outline" size={18} color={colors.textTitle} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.heroTitle}>Carte e Contanti</Text>
          <Text style={styles.heroSub}>
            Gestisci tutti i metodi di pagamento in un unico posto.
          </Text>
        </View>
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 20, gap: 12 }}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.section}>
          <SectionHeader
            icon="card-outline"
            title="Carte"
            subtitle="Associane una alle spese pagate con carta"
            onAdd={openCreateCard}
            colors={colors}
            styles={styles}
          />

          {!paymentCtx.cards.length ? (
            <View style={styles.empty}>
              <Ionicons name="information-circle-outline" size={18} color={colors.textMuted} />
              <Text style={styles.emptyText}>Nessuna carta salvata.</Text>
            </View>
          ) : (
            <View style={{ gap: 10 }}>
              {paymentCtx.cards.map((card) => (
                <View key={card.id} style={styles.cardRow}>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.cardTitle}>{card.name || "Carta"}</Text>
                    {!!(card.brand || card.last4) && (
                      <Text style={styles.cardSub}>
                        {card.brand ? `${card.brand}${card.last4 ? " - " : ""}` : ""}
                        {card.last4 ? `**** ${card.last4}` : ""}
                      </Text>
                    )}
                    <Text style={styles.cardSub}>
                      Saldo iniziale: {Number(card.balance || 0).toFixed(2)} EUR
                    </Text>
                    <Text style={styles.cardSub}>
                      Spese registrate: {Number(spentByCard.get(String(card.id)) || 0).toFixed(2)} EUR
                    </Text>
                    <Text style={styles.cardSubStrong}>
                      Saldo aggiornato: {Number(Number(card.balance || 0) - Number(spentByCard.get(String(card.id)) || 0)).toFixed(2)} EUR
                    </Text>
                  </View>

                  <Pressable
                    onPress={() => openEditCard(card)}
                    style={({ pressed }) => [styles.iconBtn, pressed && { opacity: 0.85 }]}
                  >
                    <Ionicons name="create-outline" size={18} color={colors.textTitle} />
                  </Pressable>

                  <Pressable
                    onPress={() => removeCard(card)}
                    style={({ pressed }) => [styles.iconBtnDanger, pressed && { opacity: 0.85 }]}
                  >
                    <Ionicons name="trash-outline" size={18} color={colors.textTitle} />
                  </Pressable>
                </View>
              ))}
            </View>
          )}
        </View>

        <View style={styles.section}>
          <SectionHeader
            icon="cash-outline"
            title="Contanti"
            subtitle="Crea wallet e imposta quello predefinito"
            onAdd={openCreateCash}
            colors={colors}
            styles={styles}
          />

          {!paymentCtx.cashWallets.length ? (
            <View style={styles.empty}>
              <Ionicons name="information-circle-outline" size={18} color={colors.textMuted} />
              <Text style={styles.emptyText}>Nessun wallet contanti salvato.</Text>
            </View>
          ) : (
            <View style={{ gap: 10 }}>
              {paymentCtx.cashWallets.map((wallet) => (
                <View key={wallet.id} style={styles.cardRow}>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.cardTitle}>
                      {wallet.name || "Contanti"}
                      {wallet.isDefault ? " - Predefinito" : ""}
                    </Text>
                    <Text style={styles.cardSub}>
                      Saldo: {Number(wallet.balance || 0).toFixed(2)} EUR
                    </Text>
                    <Text style={styles.cardSub}>
                      Spese registrate: {Number(spentByCashWallet.get(String(wallet.id)) || 0).toFixed(2)} EUR
                    </Text>
                    <Text style={styles.cardSubStrong}>
                      Saldo aggiornato: {Number(Number(wallet.balance || 0) - Number(spentByCashWallet.get(String(wallet.id)) || 0)).toFixed(2)} EUR
                    </Text>
                  </View>

                  {!wallet.isDefault ? (
                    <Pressable
                      onPress={() => paymentCtx.setDefaultCashWallet(wallet.id)}
                      style={({ pressed }) => [styles.iconBtn, pressed && { opacity: 0.85 }]}
                    >
                      <Ionicons name="star-outline" size={18} color={colors.textTitle} />
                    </Pressable>
                  ) : null}

                  <Pressable
                    onPress={() => openEditCash(wallet)}
                    style={({ pressed }) => [styles.iconBtn, pressed && { opacity: 0.85 }]}
                  >
                    <Ionicons name="create-outline" size={18} color={colors.textTitle} />
                  </Pressable>

                  <Pressable
                    onPress={() => removeCashWallet(wallet)}
                    style={({ pressed }) => [styles.iconBtnDanger, pressed && { opacity: 0.85 }]}
                  >
                    <Ionicons name="trash-outline" size={18} color={colors.textTitle} />
                  </Pressable>
                </View>
              ))}
            </View>
          )}
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionHeadLeft}>
              <View style={styles.sectionIconWrap}>
                <Ionicons name="receipt-outline" size={18} color={colors.textTitle} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.sectionTitle}>Ultimi pagamenti</Text>
                <Text style={styles.sectionSub}>Movimenti registrati nelle Spese</Text>
              </View>
            </View>
          </View>

          {!recentPayments.length ? (
            <View style={styles.empty}>
              <Ionicons name="information-circle-outline" size={18} color={colors.textMuted} />
              <Text style={styles.emptyText}>Nessun pagamento registrato.</Text>
            </View>
          ) : (
            <View style={{ gap: 10 }}>
              {recentPayments.map((e) => {
                const methodLabel = paymentCtx.resolveMethodLabel?.(e) || "Contanti";
                return (
                  <View key={e.id} style={styles.paymentRow}>
                    <View style={{ flex: 1 }}>
                      <Text style={styles.cardTitle} numberOfLines={1}>
                        {String(e?.description || "Spesa")}
                      </Text>
                      <Text style={styles.cardSub} numberOfLines={1}>
                        {methodLabel} - {formatDateIT(e?.date)}
                      </Text>
                    </View>
                    <Text style={styles.paymentAmount}>
                      -{Number(e?.amount || 0).toFixed(2)} EUR
                    </Text>
                  </View>
                );
              })}
            </View>
          )}
        </View>
      </ScrollView>

      <Modal
        visible={cardModalOpen}
        transparent
        animationType="fade"
        onRequestClose={() => setCardModalOpen(false)}
      >
        <View style={styles.modalBackdrop}>
          <Pressable style={StyleSheet.absoluteFill} onPress={Keyboard.dismiss} />

          <KeyboardAvoidingView
            style={styles.modalAvoid}
            behavior={Platform.OS === "ios" ? "padding" : "height"}
            keyboardVerticalOffset={Platform.OS === "ios" ? 64 : 24}
          >
            <ScrollView
              contentContainerStyle={styles.modalScroll}
              keyboardShouldPersistTaps="handled"
              keyboardDismissMode={Platform.OS === "ios" ? "interactive" : "on-drag"}
              showsVerticalScrollIndicator={false}
            >
              <View style={styles.modalCard}>
                <Text style={styles.modalTitle}>{cardDraft.id ? "Modifica carta" : "Nuova carta"}</Text>

                <Text style={styles.label}>Nome</Text>
                <TextInput
                  value={cardDraft.name}
                  onChangeText={(v) => setCardDraft((p) => ({ ...p, name: v }))}
                  placeholder="Es. N26"
                  placeholderTextColor={colors.white45}
                  style={styles.input}
                  returnKeyType="next"
                  blurOnSubmit={false}
                />

                <Text style={styles.label}>Brand (opzionale)</Text>
                <TextInput
                  value={cardDraft.brand}
                  onChangeText={(v) => setCardDraft((p) => ({ ...p, brand: v }))}
                  placeholder="Es. Visa"
                  placeholderTextColor={colors.white45}
                  style={styles.input}
                  returnKeyType="next"
                  blurOnSubmit={false}
                />

                <Text style={styles.label}>Ultime 4 cifre (opzionale)</Text>
                <TextInput
                  value={cardDraft.last4}
                  onChangeText={(v) =>
                    setCardDraft((p) => ({
                      ...p,
                      last4: String(v || "")
                        .replace(/[^\d]/g, "")
                        .slice(0, 4),
                    }))
                  }
                  keyboardType="number-pad"
                  placeholder="1234"
                  placeholderTextColor={colors.white45}
                  style={styles.input}
                  maxLength={4}
                  returnKeyType="done"
                  onSubmitEditing={Keyboard.dismiss}
                />

                <Text style={styles.label}>Saldo iniziale</Text>
                <TextInput
                  value={cardDraft.balance}
                  onChangeText={(v) => setCardDraft((p) => ({ ...p, balance: v }))}
                  keyboardType="decimal-pad"
                  placeholder="0"
                  placeholderTextColor={colors.white45}
                  style={styles.input}
                  returnKeyType="done"
                  onSubmitEditing={Keyboard.dismiss}
                />

                <View style={styles.modalActions}>
                  <Pressable
                    onPress={() => !saving && setCardModalOpen(false)}
                    style={({ pressed }) => [styles.btnGhost, pressed && { opacity: 0.86 }]}
                  >
                    <Text style={styles.btnGhostText}>Annulla</Text>
                  </Pressable>

                  <Pressable
                    onPress={saveCard}
                    style={({ pressed }) => [styles.btnPrimary, pressed && { opacity: 0.86 }]}
                    disabled={saving}
                  >
                    <Text style={styles.btnPrimaryText}>{saving ? "Salvataggio..." : "Salva"}</Text>
                  </Pressable>
                </View>
              </View>
            </ScrollView>
          </KeyboardAvoidingView>
        </View>
      </Modal>

      <Modal
        visible={cashModalOpen}
        transparent
        animationType="fade"
        onRequestClose={() => setCashModalOpen(false)}
      >
        <View style={styles.modalBackdrop}>
          <Pressable style={StyleSheet.absoluteFill} onPress={Keyboard.dismiss} />

          <KeyboardAvoidingView
            style={styles.modalAvoid}
            behavior={Platform.OS === "ios" ? "padding" : "height"}
            keyboardVerticalOffset={Platform.OS === "ios" ? 64 : 24}
          >
            <ScrollView
              contentContainerStyle={styles.modalScroll}
              keyboardShouldPersistTaps="handled"
              keyboardDismissMode={Platform.OS === "ios" ? "interactive" : "on-drag"}
              showsVerticalScrollIndicator={false}
            >
              <View style={styles.modalCard}>
                <Text style={styles.modalTitle}>{cashDraft.id ? "Modifica wallet" : "Nuovo wallet"}</Text>

                <Text style={styles.label}>Nome</Text>
                <TextInput
                  value={cashDraft.name}
                  onChangeText={(v) => setCashDraft((p) => ({ ...p, name: v }))}
                  placeholder="Es. Portafoglio"
                  placeholderTextColor={colors.white45}
                  style={styles.input}
                  returnKeyType="next"
                  blurOnSubmit={false}
                />

                <Text style={styles.label}>Saldo iniziale</Text>
                <TextInput
                  value={cashDraft.balance}
                  onChangeText={(v) => setCashDraft((p) => ({ ...p, balance: v }))}
                  keyboardType="decimal-pad"
                  placeholder="0"
                  placeholderTextColor={colors.white45}
                  style={styles.input}
                  returnKeyType="done"
                  onSubmitEditing={Keyboard.dismiss}
                />

                <View style={styles.modalActions}>
                  <Pressable
                    onPress={() => !saving && setCashModalOpen(false)}
                    style={({ pressed }) => [styles.btnGhost, pressed && { opacity: 0.86 }]}
                  >
                    <Text style={styles.btnGhostText}>Annulla</Text>
                  </Pressable>

                  <Pressable
                    onPress={saveCashWallet}
                    style={({ pressed }) => [styles.btnPrimary, pressed && { opacity: 0.86 }]}
                    disabled={saving}
                  >
                    <Text style={styles.btnPrimaryText}>{saving ? "Salvataggio..." : "Salva"}</Text>
                  </Pressable>
                </View>
              </View>
            </ScrollView>
          </KeyboardAvoidingView>
        </View>
      </Modal>
    </View>
  );
}

function makeStyles(colors) {
  return StyleSheet.create({
    screen: { flex: 1, backgroundColor: colors.bg, padding: 14 },
    hero: {
      flexDirection: "row",
      alignItems: "center",
      gap: 10,
      borderRadius: 18,
      borderWidth: 1,
      borderColor: colors.white10,
      backgroundColor: colors.surface,
      padding: 14,
      marginBottom: 12,
    },
    heroIcon: {
      width: 38,
      height: 38,
      borderRadius: 14,
      alignItems: "center",
      justifyContent: "center",
      backgroundColor: colors.surface2,
      borderWidth: 1,
      borderColor: colors.white10,
    },
    heroTitle: { color: colors.textTitle, fontWeight: "900", fontSize: 16 },
    heroSub: {
      marginTop: 2,
      color: colors.textMuted,
      fontWeight: "700",
      fontSize: 12,
    },

    section: {
      borderRadius: 18,
      borderWidth: 1,
      borderColor: colors.white10,
      backgroundColor: colors.surface,
      padding: 12,
      gap: 10,
    },
    sectionHeader: {
      flexDirection: "row",
      alignItems: "center",
      gap: 10,
      justifyContent: "space-between",
    },
    sectionHeadLeft: {
      flexDirection: "row",
      alignItems: "center",
      gap: 10,
      flex: 1,
    },
    sectionIconWrap: {
      width: 38,
      height: 38,
      borderRadius: 14,
      alignItems: "center",
      justifyContent: "center",
      backgroundColor: colors.surface2,
      borderWidth: 1,
      borderColor: colors.white10,
    },
    sectionTitle: { color: colors.textTitle, fontWeight: "900", fontSize: 14 },
    sectionSub: { color: colors.textMuted, fontWeight: "700", fontSize: 12, marginTop: 2 },

    addBtn: {
      width: 40,
      height: 40,
      borderRadius: 14,
      alignItems: "center",
      justifyContent: "center",
      borderWidth: 1,
      borderColor: colors.accent30,
      backgroundColor: colors.accent500,
    },

    empty: {
      borderRadius: 16,
      borderWidth: 1,
      borderColor: colors.white10,
      backgroundColor: colors.white06,
      padding: 12,
      flexDirection: "row",
      alignItems: "center",
      gap: 10,
    },
    emptyText: { flex: 1, color: colors.textMuted, fontWeight: "800" },

    cardRow: {
      borderRadius: 16,
      borderWidth: 1,
      borderColor: colors.white10,
      backgroundColor: colors.white06,
      padding: 12,
      flexDirection: "row",
      alignItems: "center",
      gap: 8,
    },
    paymentRow: {
      borderRadius: 16,
      borderWidth: 1,
      borderColor: colors.white10,
      backgroundColor: colors.white06,
      paddingVertical: 11,
      paddingHorizontal: 12,
      flexDirection: "row",
      alignItems: "center",
      gap: 10,
    },
    paymentAmount: {
      color: colors.accent500,
      fontWeight: "900",
      fontSize: 12,
    },
    cardTitle: { color: colors.textTitle, fontWeight: "900" },
    cardSub: {
      marginTop: 2,
      color: colors.textMuted,
      fontWeight: "700",
      fontSize: 12,
    },
    cardSubStrong: {
      marginTop: 4,
      color: colors.textBody,
      fontWeight: "900",
      fontSize: 12,
    },

    iconBtn: {
      width: 38,
      height: 38,
      borderRadius: 14,
      alignItems: "center",
      justifyContent: "center",
      borderWidth: 1,
      borderColor: colors.white10,
      backgroundColor: colors.white08,
    },
    iconBtnDanger: {
      width: 38,
      height: 38,
      borderRadius: 14,
      alignItems: "center",
      justifyContent: "center",
      borderWidth: 1,
      borderColor: colors.danger30,
      backgroundColor: colors.danger20,
    },

    modalBackdrop: {
      flex: 1,
      justifyContent: "flex-end",
      padding: 16,
      backgroundColor: colors.overlay60,
    },
    modalAvoid: {
      flex: 1,
      justifyContent: "flex-end",
    },
    modalScroll: {
      flexGrow: 1,
      justifyContent: "flex-end",
      paddingBottom: 12,
    },
    modalCard: {
      borderRadius: 18,
      borderWidth: 1,
      borderColor: colors.white10,
      backgroundColor: colors.surface,
      padding: 14,
    },
    modalTitle: {
      color: colors.textTitle,
      fontWeight: "900",
      fontSize: 16,
      marginBottom: 10,
      textAlign: "center",
    },
    label: {
      color: colors.textMuted,
      fontWeight: "800",
      fontSize: 12,
      marginBottom: 6,
      marginTop: 4,
    },
    input: {
      borderRadius: 14,
      borderWidth: 1,
      borderColor: colors.white10,
      backgroundColor: colors.surface2,
      color: colors.textTitle,
      fontWeight: "800",
      paddingHorizontal: 12,
      paddingVertical: 12,
    },
    modalActions: { flexDirection: "row", gap: 10, marginTop: 14 },
    btnGhost: {
      flex: 1,
      height: 46,
      borderRadius: 14,
      alignItems: "center",
      justifyContent: "center",
      borderWidth: 1,
      borderColor: colors.white12,
      backgroundColor: colors.white06,
    },
    btnGhostText: { color: colors.textTitle, fontWeight: "900" },
    btnPrimary: {
      flex: 1,
      height: 46,
      borderRadius: 14,
      alignItems: "center",
      justifyContent: "center",
      borderWidth: 1,
      borderColor: colors.accent30,
      backgroundColor: colors.accent500,
    },
    btnPrimaryText: { color: colors.textOnAccentStrong, fontWeight: "900" },
  });
}
