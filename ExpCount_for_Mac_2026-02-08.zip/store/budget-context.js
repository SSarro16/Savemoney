import {
  createContext,
  useState,
  useContext,
  useEffect,
  useCallback,
  useMemo,
  useRef,
} from "react";

import { AuthContext } from "./auth-context";
import {
  getBudgets,
  getBudgetById,
  getActiveBudgetId,
  setActiveBudgetId,
  createBudget,
  upsertBudget,
} from "../util/budget/budget-storage";

const DEFAULT_CATEGORIES = { Risparmio: 0, Spese: 0, Svago: 0, Altro: 0 };

export const BudgetContext = createContext({
  budgetId: null,
  budgets: [],
  activeBudgetMeta: null,

  total: 0,
  categories: DEFAULT_CATEGORIES,
  cashBalance: 0,

  setTotal: (val) => {},
  updateCategory: (cat, val) => {},
  setCashBalance: (val) => {},
  addCashDelta: (delta) => {},

  resetBudget: () => {},
  formatEuro: (val) => "0.00€",

  refreshBudgetsList: async () => {},
  selectBudget: async (id) => {},
  createNewBudget: async (name) => {},

  saveBudget: async (_patch) => {},
  loadBudget: async () => {},
});

function isAuthHttpError(error) {
  const status = Number(error?.response?.status || 0);
  return status === 401 || status === 403;
}

function BudgetContextProvider({ children }) {
  const authCtx = useContext(AuthContext);
  const userId = authCtx.userId;
  const token = authCtx.token;
  const refreshSession = authCtx.refreshSession;
  const refreshSessionRef = useRef(refreshSession);

  const [budgets, setBudgets] = useState([]);
  const [budgetId, setBudgetId] = useState(null);

  const [total, setTotalState] = useState(0);
  const [categories, setCategories] = useState(DEFAULT_CATEGORIES);
  const [cashBalance, setCashBalanceState] = useState(0);

  const ensureAuth = useCallback(() => {
    if (!userId || !token) {
      throw new Error("Auth non disponibile (token/userId mancanti).");
    }
  }, [userId, token]);

  useEffect(() => {
    refreshSessionRef.current = refreshSession;
  }, [refreshSession]);

  const withAuthRetry = useCallback(
    async (request) => {
      try {
        return await request(token);
      } catch (error) {
        if (!isAuthHttpError(error)) throw error;

        const refreshed = await refreshSessionRef.current?.(true).catch(() => null);
        const nextToken = refreshed?.token;
        if (!nextToken) throw error;

        return await request(nextToken);
      }
    },
    [token],
  );

  const refreshBudgetsList = useCallback(async () => {
    ensureAuth();
    const list = await withAuthRetry((t) => getBudgets(userId, t));
    setBudgets(list);
    return list;
  }, [ensureAuth, userId, withAuthRetry]);

  const selectBudget = useCallback(
    async (id) => {
      if (!id) return;
      await setActiveBudgetId(id, userId);
      setBudgetId(id);
    },
    [setBudgetId, userId],
  );

  const createNewBudget = useCallback(
    async (name) => {
      const b = await withAuthRetry((t) => createBudget({ name, userId, token: t }));
      const list = await refreshBudgetsList();
      setBudgets(list);
      setBudgetId(b.id);
      return b;
    },
    [refreshBudgetsList, userId, withAuthRetry],
  );

  const setTotal = useCallback((val) => {
    setTotalState(Number(val) || 0);
  }, []);

  const updateCategory = useCallback((cat, val) => {
    setCategories((prev) => ({
      ...prev,
      [cat]: Number(val) || 0,
    }));
  }, []);

  const setCashBalance = useCallback((val) => {
    setCashBalanceState(Number(val) || 0);
  }, []);

  const addCashDelta = useCallback((delta) => {
    const n = Number(delta) || 0;
    setCashBalanceState((prev) => (Number(prev) || 0) + n);
  }, []);

  const resetBudget = useCallback(() => {
    setTotalState(0);
    setCategories(DEFAULT_CATEGORIES);
    setCashBalanceState(0);
  }, []);

  const formatEuro = useCallback((val) => {
    return (Number(val) || 0).toFixed(2) + "€";
  }, []);

  const saveBudget = useCallback(
    async (patch = null) => {
      ensureAuth();
      if (!budgetId) throw new Error("Nessun budget selezionato.");

      const nextTotal =
        patch && Object.prototype.hasOwnProperty.call(patch, "total")
          ? Number(patch.total) || 0
          : Number(total) || 0;

      const nextCategories = {
        ...DEFAULT_CATEGORIES,
        ...(patch?.categories || categories || {}),
      };
      Object.keys(nextCategories).forEach((k) => {
        nextCategories[k] = Number(nextCategories[k] || 0);
      });

      const nextCashBalance =
        patch && Object.prototype.hasOwnProperty.call(patch, "cashBalance")
          ? Number(patch.cashBalance) || 0
          : Number(cashBalance) || 0;

      const patchTitle = String(patch?.title || "").trim();
      let meta = budgets.find((b) => b.id === budgetId) || null;
      if (!meta) {
        meta = await withAuthRetry((t) => getBudgetById(userId, t, budgetId));
      }

      const next = await withAuthRetry((t) =>
        upsertBudget(userId, t, {
          id: budgetId,
          title: patchTitle || String(meta?.title || meta?.name || "Nuovo budget"),
          total: nextTotal,
          categories: nextCategories,
          cashBalance: nextCashBalance,
          createdAt: meta?.createdAt,
        }),
      );
      setTotalState(nextTotal);
      setCategories(nextCategories);
      setCashBalanceState(nextCashBalance);
      setBudgets(next);
    },
    [
      ensureAuth,
      userId,
      budgetId,
      total,
      categories,
      cashBalance,
      budgets,
      withAuthRetry,
    ],
  );

  const loadBudget = useCallback(async () => {
    ensureAuth();
    if (!budgetId) return;

    const data =
      (await withAuthRetry((t) => getBudgetById(userId, t, budgetId))) ||
      budgets.find((b) => b.id === budgetId);
    if (!data) return;

    setTotalState(Number(data?.total || 0));
    setCategories({
      ...DEFAULT_CATEGORIES,
      ...(data?.categories || {}),
    });
    setCashBalanceState(Number(data?.cashBalance || 0));
  }, [ensureAuth, userId, budgetId, budgets, withAuthRetry]);

  // bootstrap budgets list + active id
  useEffect(() => {
    let isMounted = true;

    (async () => {
      if (!userId || !token) return;

      const list = await withAuthRetry((t) => getBudgets(userId, t));
      if (!isMounted) return;
      setBudgets(list);
      const active = (await getActiveBudgetId(userId)) || list?.[0]?.id || null;

      if (!isMounted) return;

      if (!active) {
        // se non esiste nulla, creane uno
        const created = await createNewBudget("Budget 1");
        if (!isMounted) return;
        setBudgetId(created.id);
      } else {
        setBudgetId(active);
      }
    })();

    return () => {
      isMounted = false;
    };
  }, [userId, token, refreshBudgetsList, createNewBudget, withAuthRetry]);

  // load budget when budgetId ready
  useEffect(() => {
    if (!userId || !token) return;
    if (!budgetId) return;

    let isMounted = true;
    (async () => {
      try {
        await loadBudget();
      } catch (err) {
        if (isMounted) console.log("Errore fetch budget:", err?.message);
      }
    })();

    return () => {
      isMounted = false;
    };
  }, [userId, token, budgetId, loadBudget]);

  const activeBudgetMeta = useMemo(() => {
    return budgets.find((b) => b.id === budgetId) || null;
  }, [budgets, budgetId]);

  const value = useMemo(
    () => ({
      budgetId,
      budgets,
      activeBudgetMeta,

      total,
      categories,
      cashBalance,

      setTotal,
      updateCategory,
      setCashBalance,
      addCashDelta,

      resetBudget,
      formatEuro,

      refreshBudgetsList,
      selectBudget,
      createNewBudget,

      saveBudget,
      loadBudget,
    }),
    [
      budgetId,
      budgets,
      activeBudgetMeta,
      total,
      categories,
      cashBalance,
      setTotal,
      updateCategory,
      setCashBalance,
      addCashDelta,
      resetBudget,
      formatEuro,
      refreshBudgetsList,
      selectBudget,
      createNewBudget,
      saveBudget,
      loadBudget,
    ],
  );

  return (
    <BudgetContext.Provider value={value}>{children}</BudgetContext.Provider>
  );
}

export default BudgetContextProvider;
